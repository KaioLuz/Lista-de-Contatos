public class Contato {
    private String nome;
    private String telefone;
    private String email;
    public Contato(String nome, String telefone, String email){
        this.setNome(nome);
        this.setTelefone(telefone);
        this.setEmail(email);
    }
    public void setNome(String novoNome) {
        if (novoNome.isEmpty()) {
            System.out.println("Nome inválido");
        } else {
            nome = novoNome;
        }
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getNome() {return nome;}
    public String getTelefone() {return telefone;}
    public String getEmail() {return email;}
    public void exibirContato(){
        System.out.println(nome);
        System.out.println(telefone);
        System.out.println(email);
    }
}
