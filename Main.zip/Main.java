public class Main {
    public static void main(String[] args){
        Contato Peter = new Contato("Peter Parker", "99808-1962","peter.parker@alu.ufc.br");
        Contato Barry = new Contato("Barry Allen", "99724-1940","barry.allen@alu.ufc.br");
        Contato Steve = new Contato("Steve Rogers","98741-1945","steve.rogers@alu.ufc.br");
        Agenda listaDeContatos = new Agenda();
        listaDeContatos.adicionarContato(Peter);
        listaDeContatos.adicionarContato(Barry);
        listaDeContatos.adicionarContato(Steve);

        listaDeContatos.listarContatos();
        listaDeContatos.buscarContato("Steve Rogers");
        listaDeContatos.removerContato("Barry Allen");
        listaDeContatos.listarContatos();
    }
}
