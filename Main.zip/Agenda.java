import java.util.ArrayList;

public class Agenda {
    private ArrayList <Contato> agenda;

    public Agenda(){
        this.agenda = new ArrayList<>();
    }

    public void adicionarContato(Contato novo) {
        agenda.add(novo);
    }
    public void listarContatos(){
        System.out.println("-----Lista De Contatos-----");
        for (int i=0; i < agenda.size(); i++){
            System.out.println(agenda.get(i).getNome());
        }
        System.out.println("---------------------------");
    }
    public Contato buscarContato(String nome) {
        for (int i = 0; i < agenda.size(); i++) {
            if (nome.equals(agenda.get(i).getNome())) {
                System.out.println("Contato encontrado");
                agenda.get(i).exibirContato();
                return agenda.get(i);
            }
        }
        System.out.println("Não encontrado");
        return null;
        }

    public void removerContato(String nome){
        Contato auxiliar = buscarContato(nome);
        if (auxiliar == null){
            System.out.println("Esse contato não existe e portanto não pode ser removido");
        }else {
            agenda.remove(auxiliar);
            System.out.println("Contato removido com sucesso");
        }
    }
}
